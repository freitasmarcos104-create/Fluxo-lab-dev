FLUXO LAB — COMPILAÇÃO DOS APLICATIVOS (HOMOLOGAÇÃO) — 0.1.0
============================================================

ESTA ENTREGA ACRESCENTA
- Workflow GitHub Actions para compilar EXE e APK em máquinas de build na nuvem.
- Script PowerShell para compilar o EXE em um Windows 10/11 x64.
- Mantém a URL de HOMOLOGAÇÃO. Não aponta para produção.

1) GERAR OS DOIS ARQUIVOS PELO GITHUB ACTIONS

A) Crie um repositório PRIVADO no GitHub.
B) Extraia o ZIP e envie o CONTEÚDO da pasta fluxo-lab-apps para a raiz do repositório.
   A pasta .github precisa ficar visível na raiz do repositório.
C) Abra a aba Actions.
D) Selecione "Build Fluxo Lab installers".
E) Clique em "Run workflow" e confirme.
F) Quando os dois trabalhos terminarem com sucesso, abra a execução e baixe:
   - fluxo-lab-windows-exe-homologacao
   - fluxo-lab-android-apk-homologacao

Os arquivos ficam disponíveis como artefatos da execução por 14 dias.
O EXE é um instalador Windows x64 sem assinatura de publicador.
O APK é DEBUG, destinado apenas a testes internos e homologação.

2) GERAR O EXE LOCALMENTE NO WINDOWS

Requisitos: Windows 10/11 x64, Node.js 22 ou compatível e internet.

Execute o arquivo:
  scripts\build-windows.ps1

Se o PowerShell bloquear a execução do script, abra uma janela PowerShell e execute:
  powershell -ExecutionPolicy Bypass -File .\scripts\build-windows.ps1

O instalador será salvo em:
  desktop\dist\

3) GERAR O APK LOCALMENTE

Requisitos: Android Studio, JDK 17, Android SDK Platform 36 e Build Tools 36.0.0.

Abra a pasta android no Android Studio, aguarde a sincronização do Gradle e execute:
  Build > Build Bundle(s) / APK(s) > Build APK(s)

O APK debug será salvo em:
  android\app\build\outputs\apk\debug\

4) LIMITES IMPORTANTES

- Estes clientes abrem o sistema web em uma janela/tela própria. Eles não são uma
  reescrita nativa de todas as telas e precisam de internet para consultar/gravar dados.
- Ambos continuam apontando somente para:
  https://fluxo-lab-homologacao.trainingmav.workers.dev/
- O APK debug não deve ser publicado na Play Store nem distribuído como release.
- Para release Android, o proprietário deverá criar e guardar uma keystore privada.
- O EXE ainda não tem assinatura digital de publicador. O Windows pode exibir aviso.
- A homologação está protegida pelo Cloudflare Access e atualmente limitada à conta
  administrativa autorizada. Não distribuir para a equipe antes de validar autenticação
  e definir os usuários permitidos no Access.
- Antes de qualquer troca para produção, testar login, upload/download de STL e ZIP,
  relatórios, navegação entre módulos e logout em Windows e Android reais.
- Nenhum Worker, banco D1, bucket R2 ou dado de produção foi alterado por esta entrega.

5) VERSÃO E CONFIGURAÇÃO

Windows: desktop\config.json
Android: android\app\src\main\java\br\com\markfree\fluxolab\MainActivity.java

A URL deve permanecer na homologação durante a validação. Não altere o endereço
para produção sem revisar primeiro o fluxo de autenticação e as permissões.

6) CUIDADO COM O REPOSITÓRIO

O repositório deve ser PRIVADO: o código do sistema não deve ser publicado em um
repositório público. O arquivo .gitignore evita enviar node_modules, arquivos de
build, configurações locais e chaves de assinatura.
