FLUXO LAB — PROJETO INICIAL DOS APLICATIVOS INSTALÁVEIS
Versão do empacotamento: 0.1.0 (homologação)

OBJETIVO
Criar um aplicativo Windows instalável (.exe) e um aplicativo Android (.apk), mantendo o Cloudflare como backend e fonte única dos dados.

O QUE ESTE PACOTE CONTÉM
1. desktop/: aplicativo Windows com Electron e configuração para gerar instalador NSIS .exe e versão portátil.
2. android/: projeto Android nativo com WebView, suporte a cookies/sessão, seletor de arquivos e downloads.

AMBIENTE DE TESTE
Os dois clientes estão configurados exclusivamente para:
https://fluxo-lab-homologacao.trainingmav.workers.dev/

NÃO ALTERAR PARA PRODUÇÃO NESTA ETAPA.
O Worker de produção, o D1 de produção e os buckets de produção não são usados por este projeto.

O QUE SIGNIFICA “APLICATIVO REAL” AQUI
Os arquivos .exe e .apk serão pacotes instaláveis próprios, com ícone e janela/tela do Fluxo Lab. O sistema de gestão continuará sendo servido pelo Cloudflare. Portanto, o app precisa de internet para consultar e gravar dados. Isso evita duplicar o banco e permite que computador, celular e tablet trabalhem sobre os mesmos registros.
Não é um aplicativo offline completo nem uma reescrita nativa de todas as telas.

WINDOWS — GERAR O EXE
Requisitos: Windows 10/11 64 bits, Node.js LTS e internet para instalar dependências.
1. Abra a pasta desktop no terminal.
2. Execute: npm install
3. Execute: npm run dist:win
4. O instalador será gerado em desktop/dist/.

Para gerar uma versão portátil sem instalador: npm run dist:portable

ANDROID — GERAR APK DE HOMOLOGAÇÃO
Requisitos: Android Studio recente, JDK 17 e Android SDK Platform 36.
1. Abra a pasta android no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Para teste interno, utilize o APK debug gerado em app/build/outputs/apk/debug/.

Para publicar ou distribuir uma versão release, será necessário configurar uma chave de assinatura (keystore). A chave e a senha devem ficar guardadas pelo proprietário, fora do código e fora deste pacote. Não envie senhas de assinatura pelo chat.

ATENÇÃO À AUTENTICAÇÃO
A aplicação Cloudflare Access da homologação atualmente permite somente o e-mail administrador já cadastrado. Isso é suficiente para validar a instalação com essa conta, mas não libera automaticamente o acesso de outros funcionários. Antes de distribuir para a equipe, a política do Access deverá ser ajustada com os e-mails autorizados. Nenhuma política foi alterada neste pacote.

LIMITES DESTA ENTREGA
Este pacote contém os projetos-fonte iniciais, não instaladores compilados. O ambiente de construção disponível nesta sessão não possui Android SDK/Gradle nem toolchain Windows para produzir e validar os binários finais. Os códigos podem ser abertos e compilados nas ferramentas indicadas acima.

VALIDAÇÕES PENDENTES ANTES DE DISTRIBUIÇÃO
- Login Cloudflare Access e login interno dentro dos dois aplicativos.
- Upload de STL/ZIP e demais arquivos usados no laboratório.
- Download de STL/ZIP e relatórios, inclusive quando autenticados.
- Navegação entre módulos e links externos.
- Teste em Windows real e em Android real.
- Definir lista de funcionários autorizados no Cloudflare Access.
- Assinatura do instalador Windows (para identificação do publicador) e assinatura release do Android.

O PWA continua disponível como opção adicional. Ele não substitui estes projetos .exe/.apk.
