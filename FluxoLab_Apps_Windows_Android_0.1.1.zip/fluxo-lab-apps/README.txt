FLUXO LAB — APLICATIVOS INSTALÁVEIS
==================================

Leia README_BUILD.txt para gerar o instalador Windows (.exe) e o pacote Android (.apk).

Projetos:
- desktop/: Electron para Windows.
- android/: Android nativo com WebView.
- .github/workflows/: compilação automatizada dos dois artefatos no GitHub Actions.
- scripts/: compilação local Windows.

Todos os clientes permanecem fixados no ambiente de HOMOLOGAÇÃO.
Não apontar para produção durante os testes iniciais.
