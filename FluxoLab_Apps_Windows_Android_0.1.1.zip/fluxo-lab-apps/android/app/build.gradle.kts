plugins {
    id("com.android.application")
}

android {
    namespace = "br.com.markfree.fluxolab"
    compileSdk = 36

    defaultConfig {
        applicationId = "br.com.markfree.fluxolab"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".homolog"
            versionNameSuffix = "-homolog"
        }
        release {
            isMinifyEnabled = false
            // A assinatura de produção será configurada fora do código-fonte,
            // usando um keystore guardado pelo proprietário do aplicativo.
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
