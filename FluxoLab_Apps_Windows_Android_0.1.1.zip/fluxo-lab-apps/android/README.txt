FLUXO LAB ANDROID — APK

Projeto Android nativo com uma Activity e WebView em tela cheia.

URL atual: homologação do Fluxo Lab.
Não altere para produção sem autorização expressa.

Requisitos:
- Android Studio recente
- JDK 17
- Android SDK Platform 36

Abra esta pasta no Android Studio e sincronize o Gradle. Depois use Build > Build Bundle(s) / APK(s) > Build APK(s).

Recursos incluídos:
- JavaScript e DOM Storage para a aplicação web.
- Cookies persistentes para sessão.
- Navegação interna limitada ao host do Fluxo Lab e Cloudflare Access.
- Links externos abertos em outros aplicativos.
- Upload via seletor de arquivos Android.
- Downloads via DownloadManager, incluindo o cookie da sessão na requisição.
- HTTPS obrigatório; tráfego HTTP e acesso a arquivos locais desativados.

A versão debug é destinada a testes. Para distribuir uma versão release, configure uma keystore própria e mantenha-a privada. Não compartilhe a senha da keystore.
