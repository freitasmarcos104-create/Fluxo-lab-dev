'use strict';

// Ponte mínima e sem APIs de sistema expostas à página remota.
// nodeIntegration permanece desativado e contextIsolation ativado.
const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('fluxoLabDesktop', Object.freeze({
  appName: 'Fluxo Lab',
  platform: 'windows-desktop'
}));
