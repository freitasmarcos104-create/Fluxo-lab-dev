FLUXO LAB DESKTOP — WINDOWS

Este projeto usa Electron para criar um aplicativo Windows com janela própria. O empacotador está configurado para produzir um instalador NSIS .exe e uma versão portátil.

URL atual: homologação do Fluxo Lab.
Arquivo config.json: permite trocar a URL e os hosts de autenticação, mas não altere para produção sem autorização expressa.

Build:
  npm install
  npm run dist:win

A pasta de saída será dist/.

Segurança:
- Node integration desativada.
- context isolation e sandbox ativados.
- Conteúdo remoto só navega no host da homologação e nos hosts Cloudflare Access configurados.
- Links externos são abertos no navegador padrão.
- Cookies e sessão permanecem no perfil local do aplicativo.

A compilação e a validação final precisam ocorrer em Windows. Sem certificado de assinatura, o Windows pode exibir aviso de publicador desconhecido ao instalar.
