FLUXO LAB V4.0.0 — PACOTE MODULAR

ESTRUTURA
index.js        Ponto de entrada do Worker.
legacy.js       Aplicação atual, preservada e ligada ao core HTTP.
core/http.js    Respostas HTTP, redirecionamento e escape HTML compartilhados.

PUBLICAÇÃO
Este pacote já foi publicado diretamente no Worker fluxo-lab-homologacao.
O ZIP é uma cópia de segurança do código modular e referência para versionamento.
Não publique este pacote no Worker de produção.

IMPORTANTE
Os arquivos .js deste ZIP correspondem aos arquivos TXT entregues separadamente.
O banco D1 não recebeu migração SQL nesta versão.
